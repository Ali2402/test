<?php
session_start();

if(empty($_SESSION['signin_ryujin']))
{
    echo "<center><h1> ACCESS DENIED </h1></center>";
    echo "<meta http-equiv='refresh' content='1;url=/ryupanel/login.php'>";
    exit;
}
require '../../app/config/config.php';
require '../../core/functions/number.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>:: <?=$config['web']['app_name'];?> [<?=$config['web']['version'];?>] - Ryujin App ::</title>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style type="text/css">
        html,body{background: #333;color: #FF8651;font-family: monospace;}
        a{color: #fff;text-decoration: none}
        nav{background: #000;padding: 4px}
        li{list-style: none;display: inline-block;padding: 5px;background: #f00}
        li:hover{background: #FF8651}
        .content{max-width: 800px;width: 70%;margin: 0 auto}
        .title{letter-spacing:8px;}.text-small{letter-spacing: 10px;font-weight: bold;}
        .bejirt{margin-top: 50px}

    </style>
</head>
<body>
<div class="content">
<table>
    <tr>
        <td><img src="../assets/logo/ryu-logo.png" style="width: 100px;height: 100px"></td>
        <td>
            <h1 class="title">RyuJin Framework</h1>
            <small class="text-small"><?=$config['web']['version'];?> - <?=$config['web']['app_name'];?></small>
        </td>
    </tr>
</table>
<nav style="">
    <li><a href="?">Home</a></li>
    <li><a href="?ryu=stats">Statistic</a></li>
    <li><a href="?ryu=logs">Logs</a></li>
    <li><a href="?ryu=config">Config</a></li>
    <li><a href="?ryu=reset">Reset Stats</a></li>
    <li><a href="?ryu=visit" target="_blank">Visit site</a></li>
    <li><a href="?ryu=logout">Logout</a></li>
</nav>
<div class="bejirt">

    <?php
    if(empty($_GET['ryu'])) { 

        $rand = ['https://apiv1.shinryujin.net//ryujin/331296116344253687.jpg',
                 'https://apiv1.shinryujin.net//ryujin/187251296995599604.gif',
                 'https://apiv1.shinryujin.net//ryujin/304837468532739500.gif',
                 'https://apiv1.shinryujin.net//ryujin/304837468532739533.gif',
                 'https://apiv1.shinryujin.net//ryujin/331296116344253713.jpg'

             ];
             $c = count($rand)-1;
             $img = $rand[rand(0,$c)];
        ?>
    <center>
    <img src="<?=$img;?>" style="width: 300px;height: 460px">
</center>
<?php
}else{

    if(isset($_GET['ryu']))
    {
        if($_GET['ryu'] == 'stats')
        {
            require 'stats.php';
        }elseif($_GET['ryu'] == 'config')
        {
            require 'config.php';
        }elseif($_GET['ryu'] == 'reset')
        {
               $logs = '../logs/';
          foreach(scandir($logs) as $l)
          {
              if(!preg_match("/log/",$l))continue;
              @unlink($logs.$l);
          }
           echo "<meta http-equiv='refresh' content='0;url=?ryu=config'>";

        }elseif($_GET['ryu'] == 'logs')
        {
            require 'logs.php';
        
        }elseif($_GET['ryu'] == 'visit')
        {
            echo "<center><br><br><b>VISITING YOUR PAGE PLEASE WAIT ~ </b></center>";
            $param = $config['app']['parameter'];
            if(preg_match("/public/",$_SERVER['REQUEST_URI'])){
            echo "<meta http-equiv='refresh' content='2;url=../../?$param'>";
            }else{
            echo "<meta http-equiv='refresh' content='2;url=../?$param'>";
            }
        }elseif($_GET['ryu'] == 'logout')
        {
            session_destroy();
            echo "<h1>GOOD BYE !</h1>";
            echo "<meta http-equiv='refresh' content='2;url=?ryu=login'>";
        }elseif($_GET['ryu'] == 'save_config')
        {
                if(isset($_POST))
                {
                    $cfg = ";;".$config['web']['app_name']." - ".$config['web']['version']." \n";
                    $cfg.= ";; UPDATED CONFIG DATE : ".date('D, Y-m-d H:i')."\n\n";
                    foreach($_POST as $key=>$val)
                    { if($key == 'submit')continue;
                        $cfg.= $key." = \"".$val."\" \n";
                       
                    }

                    $cfgfile = '../../app/config/ryujin-config.ini';
                    $fp = fopen($cfgfile,'w');
                    fwrite($fp,$cfg);
                    fclose($fp);
                    
                    echo "<meta http-equiv='refresh' content='0;url=?ryu=config'>";
                }
        }
    }
}
?>
</div>
</div>
</body>
</html>