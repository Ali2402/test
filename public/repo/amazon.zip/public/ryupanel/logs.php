<?php

$basedir = dirname(__DIR__).'/logs/';

if(isset($_GET['act']))
{
	if($_GET['act'] =='del')
	{
		@unlink($basedir.$_GET['f']);
		echo "<script>alert('success');window.location.href='?ryu=logs';</script>";
	}elseif($_GET['act'] == 'view')
	{
		echo "<textarea class='w3-input' style='width:100%;height:500px;background:transparent;color:yellow;border:1px solid red'>";
		echo file_get_contents($basedir.$_GET['f']);
		echo "</textarea>";
	}
}else{

	?>
<table class="w3-table w3-hoverable w3-bordered">
	<thead>
		<tr>
			<th>No.</th><th>Logs Name</th><th>Total</th><th>Action</th>
		</tr>

	</thead>
	<tbody>
		<?php
		
		$s = scandir($basedir);
		foreach($s as $x)
		{ if(!preg_match("/log/",$x))continue;
			$e = explode(".",$x);

			echo "<tr>";
			echo "<td>".$n++."</td>";
			echo "<td>".strtoupper($e[0])."</td>";
			echo "<td>".count_stats($e[0])."</td>";
			echo "<td>[<a href='?ryu=logs&act=del&f=$x'>DELETE</a>/<a href='?ryu=logs&act=view&f=$x'>VIEW</a>]</td>";
			echo "</tr>";
		}
		?>
	</tbody>
</table>
	<?php
}