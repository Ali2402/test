<?php
session_start();
require '../../app/config/config.php';
require '../../core/functions/number.php';
?>
<html>
<head>
<title>- Sign In - RyuJin App -</title>
<link rel="icon" type="text/css" href="/assets/logo/ryu-logo.png">
</head>
<body>
    <style>
        html,body{background: #eee;color:#888;font-family: monospace;font-weight: bold;}
        #token{background: transparent;border:2px solid #999;padding:6px;width:350px;color:#000;}
        #token:hover{box-shadow: 0px 0px 5px #FF8651}
        #activate{background: transparent;border: 1px solid yellow;color:#eee;padding:3px}
    </style>
<div style="margin-top:10%">
<center>
<img src="../assets/logo/ryu-logo.png" style="width:100px;height: 100px">
<h1>RyuJin App</h1>

<br>
<?php
 function getDomain()
   {
       $domain = preg_replace('/www\./i','',$_SERVER['SERVER_NAME']);
       $domain = ($domain == '127.0.0.1') ? 'localhost' : $domain;
       return $domain;
   }
if(isset($_POST['token']))
{
    $token = str_replace(" ","",$_POST['token']);
    if(!preg_match("/RYU/",$token))
    {
        echo "<font color=red>TOKEN NOT VALID</font><br>";
    }else{
        
        $toket = file_get_contents('../../app/config/.token');
        if($token == $toket)
        {
            $_SESSION['signin_ryujin'] = true;
            echo "<font color=lime> SUCCESS LOGGED IN</font>";
            echo "<meta http-equiv='refresh' content='2;url=/ryupanel'>";
        }else{
            echo "<font color=red>TOKEN NOT VALID</font><br>";

        }
    }
    unset($_POST);
}
?><br><br>
<form method="post">

<input type="text" name="token" id="token" autocomplete="off" placeholder="INPUT TOKEN HERE" onchange="this.form.submit()">

</form>
<br><br>
<small style="background: #000;color: #eee;padding: 3px;">[<?=$config['web']['app_name'];?>] - <b>[<?=$config['web']['version'];?>]</b> </small>
</center>
</div>
</body>
</html>
