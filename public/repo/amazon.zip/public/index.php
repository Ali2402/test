<?php
/**
* @package RyuFramework
* 
* @author shinryu
* @version v1.0-21
* @copyright 2021 shinryujin
*
*
* @disclaimer : 
* This is software for personal use, misuse of this software is not the responsibility of us (the owner). 
* All legal forms are submitted to their respective users 
*
**/
session_start();
error_reporting(0);

define('SEPARATOR',DIRECTORY_SEPARATOR);
define('PUBLIC_PATH',__DIR__.'/');
define('APP_PATH',dirname(__DIR__) . '/app/');
define('CORE_PATH',dirname(__DIR__).'/core/');
define('LANG_PATH',dirname(__DIR__) .'/core/languages/');
define('BOT_PATH',dirname(__DIR__).'/core/bots/');
define('FUNC_PATH',dirname(__DIR__) .'/core/functions/');
define('LIB_PATH',dirname(__DIR__) .'/core/libraries/');

define('REQ_PATH', dirname(__DIR__) .'/app/request/');
define('PAGE_PATH',dirname(__DIR__) .'/app/pages/');
define('CONFIG_PATH',dirname(__DIR__) .'/app/config/');

require_once(dirname(__DIR__).'/core/RyuFramework.php');
$ryu = new RyuFramework;
$ryu->run();