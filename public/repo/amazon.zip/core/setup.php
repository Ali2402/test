<html>
<head>
<title>- RyuJin App -</title>
<link rel="icon" type="text/css" href="/assets/logo/ryu-logo.png">
</head>
<body>
    <style>
        html,body{background: #eee;color:#888;font-family: monospace;font-weight: bold;}
        #token{background: transparent;border:2px solid #999;padding:6px;width:350px;color:#000;}
        #token:hover{box-shadow: 0px 0px 5px #FF8651}
        #activate{background: transparent;border: 1px solid yellow;color:#eee;padding:3px}
    </style>
<div style="margin-top:10%">
<center>
<img src="<?=$this->sec->image_encode(PUBLIC_PATH.'/assets/logo/ryu-logo.png');?>" style="width:100px;height: 100px">
<h1>RyuJin App</h1>

<br>
<?php
 function getDomain()
   {
       $domain = preg_replace('/www\./i','',$_SERVER['SERVER_NAME']);
       $domain = ($domain == '127.0.0.1') ? 'localhost' : $domain;
       return $domain;
   }
if(isset($_POST['token']))
{
    $token = str_replace(" ","",$_POST['token']);
    if(!preg_match("/RYU/",$token))
    {
        echo "<font color=red>TOKEN NOT VALID</font><br>";
    }else{
        $tokendir = dirname(__DIR__).'/app/config/.token';
        $hta = dirname(__DIR__).'/htaccess.txt'; 
        $f = file_put_contents($tokendir,$token);
        $htf = file_get_contents($hta);
        $str = str_replace('{domain}', getDomain() , $htf);
        $f.= file_put_contents(dirname(__DIR__) . '/.htaccess',$str);
        
        if($f)
        {
            echo "<font color=lime>TOKEN SAVED </font><br>";@unlink(dirname(__DIR__) .'/index.php');
            echo "<font color=grey><small>Please wait 5 seconds .. </small></font>";
            echo "<meta http-equiv='refresh' content='5;url=/ryupanel'>";
        }else{
            echo "<font color=yellow>TOKEN CAN'T SAVE </font><br>";
        }
    }
}
?><br><br>
<form method="post">

<input type="text" name="token" id="token" autocomplete="off" placeholder="INPUT TOKEN HERE" onchange="this.form.submit()">

</form>
<br><br>
<small style="background: #000;color: #eee;padding: 3px;">[<?=CONFIG['web']['app_name'];?>] - <b>[<?=CONFIG['web']['version'];?>]</b> </small>
</center>
</div>
</body>
</html>
