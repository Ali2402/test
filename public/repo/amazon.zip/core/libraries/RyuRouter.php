<?php


Class RyuRouter{
	
	public $route_config;
	public function __construct(){
		$this->route_config = CONFIG['route'];
	}
	public function init($cfg,$page)
	{
		$num = array_search($page, $this->route_config);
		$next_page = $this->route_config[$num+1];
		$route_config = $this->route_config['config'][$num+1]; 

		if(isset($num))
		{
			if($route_config == '' || empty($route_config))
			{
				return $next_page;
			}else{
				if($this->is_on($route_config))
				{
					return $next_page;
				}else{
					return $this->route_config[$num+2];
				}
			}

		}else{

			return CONFIG['app']['default_page'];
		}
	}
	public function is_on($cfg_name)
	{
		if(CONFIG['app'][$cfg_name] == 1)
		{
			return true;
		}else{
			return false;
		}
	}
}