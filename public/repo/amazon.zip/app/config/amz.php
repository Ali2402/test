<?php

$config['amz']['amz_logo'] = 'amazon1.png';
$config['amz']['step_logo'] = '1.png';
$config['amz']['step2_logo'] = '2.png';
$config['amz']['step3_logo'] = '3.png';
$config['amz']['redirect'] = 'http://www.amazon.com/gp/help/customer/display.html?ie=UTF';
$config['amz']['domain'] = 'Amazon.com';