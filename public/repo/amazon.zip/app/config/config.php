<?php


$BASE_CFG = __DIR__;
$SCAN_APP = scandir($BASE_CFG);
$EXCEPT   = ['.','..','config.php','index.php','index.html','.token','ryujin-config.ini'];

foreach($SCAN_APP as $CFG)
{
	if(in_array($CFG,$EXCEPT))continue;

	require_once $BASE_CFG.'/'.$CFG;
}