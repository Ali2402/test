<?php

$parse = parse_ini_file(__DIR__.'/ryujin-config.ini',true);

$config['app'] = $parse;
