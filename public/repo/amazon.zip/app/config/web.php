<?php
/**
* RYUJIN APP 
* CONFIGURATION 
* 
* DATE GENERATED : Mon, 17-05-2021 05:13
**/

$config['web']['app_name']     = 'Amazon';
$config['web']['version']      = 'v2.0';
$config['web']['default_page'] = 'signin';
$config['web']['api_url']      = 'https://apiv1.shinryujin.net';
