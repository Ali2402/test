<?php
/** 
* @package RyuFramework
* @version 1.0-21
* @author shinryu
* 
*------------------
* SERVER SIGNATURE : e423185a7aa023f79f7da75ff8a578c421d22289 | BUILD AT : Sat, 03-07-2021 17:35 (Asia/Jakarta)
*------------------
**/
require 'app/config/config.php';

?>
<html>
<head>
<title>- RyuJin App -</title>
<link rel="icon" type="text/css" href="public/assets/logo/ryu-logo.png">
</head>
<body>
    <style>
        html,body{background: #eee;color:#888;font-family: monospace;font-weight: bold;}
        #token{background: transparent;border:2px solid #999;padding:6px;width:350px;color:#000;}
        #token:hover{box-shadow: 0px 0px 5px #FF8651}
        #activate{background: transparent;border: 1px solid yellow;color:#eee;padding:3px}
    </style>
<div style="margin-top:10%">
<center>
<img src="public/assets/logo/ryu-logo.png" style="width:100px;height: 100px">
<h1>RyuJin App</h1>

<br>
<?php
 function getDomain()
   {
       $domain = preg_replace('/www\./i','',$_SERVER['SERVER_NAME']);
       $domain = ($domain == '127.0.0.1') ? 'localhost' : $domain;
       return $domain;
   }
if(isset($_POST['token']))
{
    $token = str_replace(" ","",$_POST['token']);
    if(!preg_match("/RYU/",$token))
    {
        echo "<font color=red>TOKEN NOT VALID</font><br>";
    }else{
        $tokendir = __DIR__.'/app/config/.token';
        $hta = __DIR__.'/htaccess.txt'; 
        $f = file_put_contents($tokendir,$token);
        $htf = file_get_contents($hta);
        $str = str_replace('{domain}', getDomain() , $htf);
        $f.= file_put_contents(__DIR__. '/.htaccess',$str);
        
        if($f)
        {
            echo "<font color=lime>TOKEN SAVED </font><br>";
            echo "<font color=grey><small>Please wait 5 seconds .. </small></font>";
            echo "<meta http-equiv='refresh' content='5;url=/ryupanel'>";
        }else{
            echo "<font color=yellow>TOKEN CAN'T SAVE </font><br>";
        }
    }
}
?><br><br>
<form method="post">
<b><font color="red">Input token for activate the application.</font></b><br>
<input type="text" name="token" id="token" autocomplete="off" placeholder="INPUT TOKEN HERE" onchange="this.form.submit()">

</form>
<br><br>
<small style="background: #000;color: #eee;padding: 3px;">[<?=$config['web']['app_name'];?>] - <b>[<?=$config['web']['version'];?>]</b> </small>
</center>
</div>
</body>
</html>
